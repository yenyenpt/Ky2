
//Bai1
var diem = prompt("Bai1:Vui long nhap diem: ");
if(diem > 0 && diem <= 5){
    console.log("Hoc luc yeu!");
}else if(diem >= 5 && diem <= 6.5){
    console.log("Hoc luc trung binh!");
}else if(diem >= 6.5 && diem <= 8){
    console.log("Hoc luc kha!");
}else if(diem >= 8 && diem <= 10){
    console.log("Hoc luc gioi!");
}else{
    console.log("Diem loi, vui long nhap lai!");

}
//Bai2

var chieuDai = prompt("Bai2: Vui long nhap chieu dai: ");

if(chieuDai >= 10 && chieuDai <= 15){
    console.log("Chuoi tam duoc!");
}else if(chieuDai <= 0){
    console.log("Nhap sai, vui long nhap lai!");
}else{
    console.log("Chuoi khung, mua ngay!");
}
//Bai 3

var tienGoc = 1000;

    var tongTienLai;
    var tongTien;
        for(i = 1; i < 12; i++){
        tongTienLai = ((tienGoc *10)/100)*i;
        console.log("Tien lai:"+tongTienLai);

        tongTien = tienGoc + tongTienLai;
        console.log("Tong tien "+i+" thang: "+ tongTien);


        }
        
    //Bai4
   
    var n = prompt("Bai4: Vui long nhap n: ");
    var dem = 0;
    for(i = 1; i < n; i++){
        if(i % 2 == 0){
            console.log(i);
            dem++;
           
        }
        
    }
    console.log("Day la cac so chia het cho 2!");
    
    //Bai5
    var x = prompt("Bai5: Vui long nhap x: ");
    if(isNaN(x) == false){
        console.log("Day la so!!")
    }else{
        console.log("Day k phai so!!")
    }
    //Bai6
    var tenSV = prompt("Bai6: Vui long nhap ten sinh vien: ");
    var diem = prompt("Vui long nhap diem sinh vien: ");
    
    switch(diem){
        case "A":
        case "B":
        case "C":
            console.log("Sinh vien da qua mon!!!");
        case "D":
        case "F":
            console.log("Sinh vien da khong qua mon!!!");
        default:
            console.log("Diem cua sinh vien k xac dinh dc!!");



    }
    //Bai7
    var soLuongBo = 1000;
    var soLuongBoMuaThem = 0;
    console.log("So luong bo ban dau: "+soLuongBo);
    for( i = 1; i <= 9; i++){
        soLuongBoMuaThem += 15;
        console.log("So luong bo mua them duoc sau thang "+i+"la: "+soLuongBoMuaThem);


    }
    console.log("Tong so luong bo sau khi mua them: "+(soLuongBoMuaThem + soLuongBo));
    //Bai8
    var hoTen = prompt("Bai8: Vui long nhap ho ten: ");
    var tuoi = prompt("Bai8: Vui long nhap tuoi: ");
    var muaLuong = prompt("Bai8: Vui long nhap mua luong: ");
    var thang = prompt("Bai8: Nhap so thang: ");
    var tienThuong;

    console.log("Tong luong: "+(muaLuong*thang));
    if(thang <= 3){
        tienThuong = 2000000;
        console.log("Ban duoc thuong "+tienThuong);
    }else if(thang >= 3 && thang <= 6){
        tienThuong = 6000000;
        console.log("Ban duoc thuong "+tienThuong);

    }else{
        tienThuong = 12000000;
        console.log("Ban duoc thuong "+tienThuong);
    }
    console.log("Tong thu nhap ca luong va thuong: "+((muaLuong*thang)+tienThuong));

        //Bai9
    var diemLab = prompt("Bai 9: Vui long nhap diem lab: ");
    var diemQuiz = prompt("Bai 9:Vui long nhap diem quiz: ");
    var diemAss = prompt("Bai 9:Vui long nhap diem ass: ");
    var diemThi = prompt("Bai 9:Vui long nhap diem diem thi: ");
    var diemTrungBinh = diemLab*0.3 + diemQuiz*0.1 + diemAss*0.2 + diemThi *0.4;
    if(diemLab < 0 || diemQuiz < 0 || diemAss < 0 ||diemThi < 0 || diemLab > 10 || diemQuiz > 10 || diemAss > 10 ||diemThi > 10 ){
        console.log("Loi nhap diem!!");
    }else{
        console.log("Diem trung binh: "+diemTrungBinh);
        console.log("Diem lab: "+diemLab);
        console.log("Diem quiz: "+diemQuiz);
        console.log("Diem Ass: "+diemAss);
        console.log("Diem thi: "+diemThi);

        if(diemTrungBinh < 5){
            console.log("Ban da truot mon!!")
        }else{
            console.log("Ban da qua mon!!");
        }
    }
    //Bai 10
    var so = prompt("Vui long nhap so bat ki: ");
    var tong = 0;
    if(so < 0){
        console.log("Nhap lai.Vui long nhap so duong!")
    }else{
        for(i = 0 ; i <= so; i++){
            if(i %3 == 0 && i %5 == 0){
                tong += i;
            
            }
        }
        console.log("Day la so chia het cho 3 va 5!!")

        
    }
   

