/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.poly;


public class debai{
    public static void main(String[] args) {
        
        System.out.println("Bài 1: Viết chương trình cho phép nhập họ và tên sinh viên, điểm trung bình từ bàn\n" +
"phím sau đó xuất ra màn hình với định dạng: Ho ten: Nguyen Van An – Diem: 8.5");
        System.out.println("Bài 2: Viết chương trình nhập từ bàn phím 2 cạnh của hình chữ nhật. Tính và xuất chu vi,\n" +
"diện tích và cạnh nhỏ của hình chữ nhật");
        System.out.println("Bài 3: Viết chương trình nhập từ bàn phím cạnh của một khối lập phương. Tính và xuất\n" +
"thể tích của khối lập phương");
        System.out.println("Bài 4: Viết chương trình nhập các hệ số của phương trình bậc 2. Tính delta và xuất căn\n" +
"delta ra màn hình");
        System.out.println("Bài 5: Viết chương trình nhập vào 3 số nguyên từ bàn phím. Hiển thị ra màn hình số nhỏ\n" +
"nhất trong 3 số vừa nhập");
    }
    
}
