/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javaapplication83;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

/**
 *
 * @author hoangthang
 */
public class QuanLySinhVien {
    //viết các chức năng vào đây 
    public ArrayList<SVPoly> list;

    public QuanLySinhVien() {
    }

    public QuanLySinhVien(ArrayList<SVPoly> list) {
        this.list = list;
    }
    //1.Thêm sinh viên vào danh sách
    public void themSinhVien(SVPoly sv) {
        list.add(sv);
    }
    //2.In ra danh sách sinh viên
    public void inDanhSachSinhVien(){
        for(SVPoly sv:list){
            System.out.println(sv);
        }
    }
    //3 Sửa sinh viên theo tên 
    public void suaSinhVienTheoTen(String ten,SVPoly sv) {
            int vitri = layVTSinhVienTheoTen(ten);
            list.set(vitri, sv);
    }
    //lấy vị trí sinh viên theo tên
    public int layVTSinhVienTheoTen(String ten) {
        int viTri = 0;
        for(int i = 0;i < list.size();i++) {
            if(list.get(i).getHoTen().equals(ten)) {
                viTri = i;
            }
        }
        return viTri;
    }
    //4 xuất danh sách sinh viên theo khoảng điểm từ min đến max;
    public void xuatDanhSachSinhVienTheoKhoangDiem(double diemMin,double diemMax) {
        System.out.println("Danh sách sinh viên có điểm trong khoảng từ"
        + diemMin + "-" + diemMax 
        );
        for(SVPoly sv:list){
            if(sv.getDiem() >= diemMin && sv.getDiem() <= diemMax){
                System.out.println(sv);
            }
        }
    }
    //5 tìm sinh viên theo tên
    public void timSinhVien(String ten) {
     System.out.println("Danh sách sinh viên có tên"+ten+" là:" );
        for(SVPoly sv:list) {
            if(sv.getHoTen().equals(ten)) {
                System.out.println(sv);
            }
        }
    }
    //6 Xóa sinh viên theo tên 
    public void xoaSinhVienTheoTen(String ten) {
        int viTri = layVTSinhVienTheoTen(ten);
        list.remove(viTri);
        System.out.println("Xóa sinh viên thành công");
    }
    //7 Sắp xếp sinh viên tăng dần theo điểm
    public void sapXepSVTangDanTheoDiem() {
        Collections.sort(list, new Comparator<SVPoly>(){
            @Override
            public int compare(SVPoly o1, SVPoly o2) {
               return o1.diem.compareTo(o2.diem);
            }
        
        });
    }
}
