/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package javaapplication83;

import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author hoangthang
 */
public class JavaApplication83 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        ArrayList<SVPoly> listSV = new ArrayList<SVPoly>();
        QuanLySinhVien qlsv = new QuanLySinhVien(listSV);
        Scanner sc = new Scanner(System.in);
        int luachon = 0;
        do {
            System.out.println("1. Nhập sinh viên");
            System.out.println("2. Xuất sinh viên");
            System.out.println("3. Sửa sinh viên theo tên");
            System.out.println("4. Hiển thị sinh viên theo khoảng điểm");
            System.out.println("5. Tìm sinh viên viên theo tên");
            System.out.println("6. Xóa sinh viên viên theo tên");
            System.out.println("7. Sắp xếp sinh viên viên theo điểm tăng");
            System.out.println("Mời bạn nhập vào lựa chọn");
            luachon = Integer.parseInt(sc.nextLine());
            switch(luachon) {
                case 1:
                    System.out.println("Nhập vào tên");
                    String hoTen = sc.nextLine();
                    System.out.println("Nhập vào điểm");
                    double diem = Double.parseDouble(sc.nextLine());
                    SVPoly sv1 = new SVPoly(hoTen,diem);
                    qlsv.themSinhVien(sv1);
                    break; 
                case 2:
                    qlsv.inDanhSachSinhVien();
                    break;
                case 3:
                    System.out.println("Nhập vào tên sinh viên cần sửa");
                    String tenSVSua = sc.nextLine();
                    System.out.println("Nhập vào tên sinh viên mới");
                    String tenSVMoi = sc.nextLine();
                    System.out.println("Nhập vào điểm sinh viên mới");
                    double diemSVMoi = Double.parseDouble(sc.nextLine());
                    SVPoly svNew = new SVPoly(tenSVMoi,diemSVMoi);
                    qlsv.suaSinhVienTheoTen(tenSVSua, svNew);
                    break;
                case 4:
                    System.out.println("Nhập vào điểm nhỏ nhất");
                    double diemMin = Double.parseDouble(sc.nextLine());
                    System.out.println("Nhập vào điểm lớn nhất");
                    double diemMax = Double.parseDouble(sc.nextLine());
                    qlsv.xuatDanhSachSinhVienTheoKhoangDiem(diemMin, diemMax);
                    break;
                case 5:
                    System.out.println("Nhập vào tên sinh viên cần tìm");
                    String tenSVTim = sc.nextLine();
                    qlsv.timSinhVien(tenSVTim);
                    break;
                case 6:
                    System.out.println("Nhập vào tên sinh viên cần Xóa");
                    String tenSVXoa = sc.nextLine();
                    qlsv.xoaSinhVienTheoTen(tenSVXoa);
                    break;
                case 7:
                    qlsv.sapXepSVTangDanTheoDiem();
                    System.out.println("Danh sách sinh viên sau khi sắp xếp là");
                    qlsv.inDanhSachSinhVien();
                    break;
                    
            }
        } while (luachon >=1 && luachon <=8);
    }
    
}
