/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javaapplication83;

/**
 *
 * @author hoangthang
 */
public class SVPoly {
    public String hoTen;
    public Double diem;//đối với số thực hoặc số nguyên viết hoa chữ đầu
    

    public SVPoly() {
    }

    public SVPoly(String hoTen, double diem) {
        this.hoTen = hoTen;
        this.diem = diem;
    }

    public String getHoTen() {
        return hoTen;
    }

    public void setHoTen(String hoTen) {
        this.hoTen = hoTen;
    }

    public double getDiem() {
        return diem;
    }

    public void setDiem(double diem) {
        this.diem = diem;
    }

    @Override
    public String toString() {
        return "SVPoly{" + "hoTen=" + hoTen + ", diem=" + diem + '}';
    }
    
}
